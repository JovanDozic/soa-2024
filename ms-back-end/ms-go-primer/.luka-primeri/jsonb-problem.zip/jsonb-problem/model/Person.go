package model

import (
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type Person struct {
	ID        uuid.UUID `json:"id"`
	Firstname string    `json:"firstname" gorm:"type:string"`
	Lastname  string    `json:"lastname" gorm:"type:string"`
}

func (person *Person) BeforeCreate(scope *gorm.DB) error {
	person.ID = uuid.New()
	return nil
}
